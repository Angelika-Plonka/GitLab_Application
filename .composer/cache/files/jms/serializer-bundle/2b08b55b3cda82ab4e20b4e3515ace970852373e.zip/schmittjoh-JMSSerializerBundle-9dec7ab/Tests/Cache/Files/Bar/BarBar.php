<?php

namespace JMS\SerializerBundle\Tests\Cache\Files\Bar;
class BarBar
{

}

