<?php

namespace JMS\SerializerBundle\Tests\Cache\Files {
    class Foo
    {

    }
}
